# death star

## A* but smarter

This is a dyamic global planning method which uses A* to plan on a mesh which is generated using PRM  (Probabilistic Roadmap). 

This package is depends on [dunamic_global_planner](https://github.com/KrishnaBhatu/dynamic_global_planner) package. Refere the readme in that repository to understand the planner algorithm and instructions to use it.

